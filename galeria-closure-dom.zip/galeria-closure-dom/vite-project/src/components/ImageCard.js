import { imagesData } from "../data/images";


export function createImageCard(image, onImageClick, onFavoriteToggle){
    //contenedor principal
    const card = document.createElement("div");
    card.className = 
        "bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300 hover:scale-105 cursor-pointer group relative";
    card.dataset.imageId = image.id;


    const img = document.createElement("img");
    img.src = image.url;
    img.alt = image.title;
    img.className = "w-full h-64 object-cover group-hover:opacity-90 transition-opacity";
    //img.onerror= () => img.src = "aqui iria la url de una iamgen que simbolice no disponible";
    card.appendChild(img);

    // gestionar el corazón de favorito

    //informacion de la imagen
    const infoContainer = document.createElement("div");
    infoContainer.className = "p-4 bg-white";

    const title = document.createElement("h3");
    title.className = "font-bold text-lg text-gray-600 mb-2";
    title.textContent = image.title;
    infoContainer.appendChild(title);

    const author = document.createElement("p");
    author.className = "font-semibold text-sm text-gray-600";
    author.textContent = `Autor: ${image.author}`;
    infoContainer.appendChild(author);

    //evento de la tarjeta
    card.onclick = () => {
        alert(image.id); //la sustituire por imageClick
    }

    //introducir en card toda la informacion
    card.appendChild(infoContainer);


    //retirnar el componente
    return{
        element: card,
        //aqui iran las funciones 
        //isFavorite -> Es favorita la imagen? 
        //setFavorite -> convertir en favorita una imagen

    }
    










    
   
    

    


}

export function createImageGrid(images, onImageClick, onFavoriteToggle){
    // creamos un map privado que guarde las tarjetas
    const cards = new Map();
    const grid = document.createElement("div");
    grid.className = "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6";

    // crear cada tarjeta con createImageCard

    images.forEach(image => {
        const cardComponent = createImageCard(
            image,
            onImageClick,
            onFavoriteToggle
        );
        cards.set(image.id, cardComponent);
        grid.appendChild(cardComponent.element);
        
    })

    return {
        element: grid, 
        
    }




}

