

export default function createImageModal() {

    const modal = document.createElement("div");
    modal.className= "fixed top-0 left-0 w-full h-full bg-black bg-opacity-50 flex justify-center items-center z-50";
    const modalContent = document.createElement("div");
    



//cerrar la imagen modal
// que sea click o ESC 
  return {}
}
