import { imagesData } from "../data/images";
import { createImageGrid } from "./ImageCard";



export default function createGalleryApp() {
    //contendor principal
    const container = document.createElement("div");
    container.className= "min-h-screen bg-linear-to-br from-purple-300 via-white to-blue-300";


    // -Header
    const header = document.createElement("header");
    header.className = "bg-white shadow-lg stickly top-0 z-40"

    const headerConstentDiv = document.createElement("div");
    headerConstentDiv.className = "max-w-7xl mx-auto px-6 py-6"

    const headerTitle = document.createElement("h1");
    headerTitle.className = "text-3xl font-bold text-purple-800 mb-2";
    headerTitle.textContent = "🎨 Galería de Imágenes";

    const headerSubtitle = document.createElement("p");
    headerSubtitle.className = "text-gray-600";
    headerSubtitle.textContent = "Aprender closures, funcione fábrica y manipulación del DOM"

    headerConstentDiv.appendChild(headerTitle);
    headerConstentDiv.appendChild(headerSubtitle);
    header.appendChild(headerConstentDiv);
    







    // -Main
    const main = document.createElement("main");
    main.className = "max-w-7xl mx-auto px-6 py-8"

    //contador de favoritos
    const counterComponent = document.createElement("h2");
    counterComponent.textContent = "Aqui va contador favoritos"

    //modal de imagen
    const imageModal = document.createElement("h2");
    imageModal.textContent = "Componente ImageModal";

    //grid de imagenes
    const gridComponent = document.createElement("h2");
    gridComponent.textContent = "Componente Grid";
    const imageComponent = createImageGrid(imagesData);
    gridComponent.appendChild(imageComponent.element);
    
    


    //añadimos todo al main
    main.appendChild(counterComponent);
    main.appendChild(imageModal);
    main.appendChild(gridComponent);


    //- Footer
    const footer = document.createElement("footer");
    footer.className = "bg-gray-900 text-white py-8 mt-15"

    const footerConstentDiv = document.createElement("div");
    footerConstentDiv.className = "max-w-7xl mx-auto px-6 text-center";

    const footerText = document.createElement("p");
    footerText.className = "text-gray-300 text-center";
    footerText.textContent = "Ejercicio de DOM de Rita Vicente Dominguez";

    const footerUrl = document.createElement("a");
    footerUrl.className = "text-gray-300 text-center";
    footerUrl.href = "https://github.com/ritaVD";

    container.appendChild(footer);
    footerConstentDiv.appendChild(footerText);
    footerConstentDiv.appendChild(footerUrl);
    footer.appendChild(footerConstentDiv);
    






  //añadimos todo al container
  container.appendChild(header);
  container.appendChild(main);  
  container.appendChild(footer);


  return {
    element : container,
  }
};
